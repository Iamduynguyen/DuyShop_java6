package com.example.webproductspringboot.utils;

//import org.modelmapper.ModelMapper;

import org.modelmapper.ModelMapper;

public class MapperModelUtils<Dto, Entity> {

    private static ModelMapper modelMapper;
    private static MapperModelUtils mapperModelUtils;

    public Dto toDto(Entity entity, Class<Dto> classDto) {
        return modelMapper.map(entity, classDto);
    }

    public Entity toEntity(Dto dto, Class<Entity> classEntity) {
        return modelMapper.map(dto, classEntity);
    }

    public static MapperModelUtils get() {
        if (mapperModelUtils == null) {
            mapperModelUtils = new MapperModelUtils();
            modelMapper = new ModelMapper();
        }
        return mapperModelUtils;
    }

}

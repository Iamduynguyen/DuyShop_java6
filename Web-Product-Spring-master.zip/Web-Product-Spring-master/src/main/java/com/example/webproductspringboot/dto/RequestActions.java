package com.example.webproductspringboot.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class RequestActions {

    private Boolean add;
    private Boolean edit;
    private String block;
    private String status;

}

package com.example.webproductspringboot.utils;

public class ContainsUtils {

    public final static String ROLE_USER = "USER";
    public final static String ROLE_STAFF = "STAFF";
    public final static String ROLE_ADMIN = "ADMIN";
    public final static String ROLE_SUPPER_ADMIN = "SUPPER_ADMIN";

    public final static String CONFIRM_REGISTER = "CONFIRM_REGISTER";

}

import React from 'react';

const BrandAPI =  {

};

export default BrandAPI;

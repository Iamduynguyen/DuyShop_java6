import React from 'react';

const ProfileView = () => {
    return (
        <div>
            
        </div>
    );
};

export default ProfileView;

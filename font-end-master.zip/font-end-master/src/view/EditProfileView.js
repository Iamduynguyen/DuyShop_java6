import React from 'react';

const EditProfileView = () => {
    return (
        <div>
            
        </div>
    );
};

export default EditProfileView;

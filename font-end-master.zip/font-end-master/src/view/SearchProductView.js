import React from 'react';

const SearchProductView = () => {
    return (
        <div>
            
        </div>
    );
};

export default SearchProductView;

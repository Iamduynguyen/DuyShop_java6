import React from 'react';

const SearchProductPage = (props) => {
    return (
        <>

        </>
    );
};

export default SearchProductPage;

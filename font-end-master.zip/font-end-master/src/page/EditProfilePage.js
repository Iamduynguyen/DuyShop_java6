import React from 'react';

const EditProfilePage = (props) => {
    return (
        <>

        </>
    );
};

export default EditProfilePage;

import React from 'react';

const ProfilePage = (props) => {
    return (
        <>

        </>
    );
};

export default ProfilePage;

import React from 'react';

const ForgotPage = () => {

    return (
        <div>

        </div>
    );
};

export default ForgotPage;
